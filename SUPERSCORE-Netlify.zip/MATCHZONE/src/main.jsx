import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { Activity, CalendarDays, ChevronDown, CircleHelp, Clock3, Globe2, Heart, Languages, Menu, Search, Star, Trophy, TrendingUp, X, Download, Flame } from "lucide-react";
import "./style.css";

const API = "/.netlify/functions/scores";
const translations = {
  Français: { live:"En direct", today:"Aujourd’hui", tomorrow:"Demain", football:"Football", tennis:"Tennis", all:"Tous les sports", favorites:"Favoris", standings:"Classements", stats:"Statistiques", search:"Rechercher une équipe ou un joueur…", noMatches:"Aucun match trouvé", loading:"Chargement des résultats…", demo:"Exemples de démonstration", powered:"Données fournies par SportScore", refresh:"Actualiser", upcoming:"À venir", finished:"Terminé", allMatches:"Tous les matchs", emptyFav:"Ajoutez des matchs aux favoris avec ☆", apiError:"Données en direct indisponibles pour le moment. Les exemples restent visibles." },
  العربية: { live:"مباشر", today:"اليوم", tomorrow:"غدوة", football:"كرة القدم", tennis:"التنس", all:"كل الرياضات", favorites:"المفضلة", standings:"الترتيب", stats:"الإحصائيات", search:"ابحث عن فريق أو لاعب…", noMatches:"ما فماش مقابلات", loading:"جاري تحميل النتائج…", demo:"أمثلة تجريبية", powered:"البيانات من SportScore", refresh:"تحديث", upcoming:"قادمة", finished:"انتهت", allMatches:"كل المقابلات", emptyFav:"زيد مقابلات للمفضلة بالضغط على ☆", apiError:"النتائج المباشرة غير متاحة مؤقتاً. الأمثلة ما زالت ظاهرة." },
  English: { live:"Live", today:"Today", tomorrow:"Tomorrow", football:"Football", tennis:"Tennis", all:"All sports", favorites:"Favorites", standings:"Standings", stats:"Statistics", search:"Search teams or players…", noMatches:"No matches found", loading:"Loading scores…", demo:"Demo examples", powered:"Data provided by SportScore", refresh:"Refresh", upcoming:"Upcoming", finished:"Finished", allMatches:"All matches", emptyFav:"Add matches to favorites with ☆", apiError:"Live data is temporarily unavailable. Demo examples remain visible." }
};
const demoMatches = [
  {id:"demo1", sport:"football", league:"Premier League", home:"Arsenal", away:"Chelsea", homeScore:2, awayScore:1, status:"LIVE", minute:"67′"},
  {id:"demo2", sport:"football", league:"La Liga", home:"Real Madrid", away:"Barcelona", homeScore:1, awayScore:1, status:"LIVE", minute:"52′"},
  {id:"demo3", sport:"football", league:"Ligue 1", home:"PSG", away:"Marseille", homeScore:0, awayScore:0, status:"SCHEDULED", minute:"21:00"},
  {id:"demo4", sport:"tennis", league:"ATP · Singles", home:"J. Sinner", away:"C. Alcaraz", homeScore:"1", awayScore:"1", status:"LIVE", minute:"Set 3"},
  {id:"demo5", sport:"tennis", league:"WTA · Singles", home:"I. Świątek", away:"C. Gauff", homeScore:"2", awayScore:"0", status:"FINISHED", minute:"Final"}
];
function normalise(raw, sport, i) {
  const home = raw.home_team || raw.home || raw.homeTeam || raw.participants?.[0]?.name || raw.home_name;
  const away = raw.away_team || raw.away || raw.awayTeam || raw.participants?.[1]?.name || raw.away_name;
  if (!home || !away) return null;
  const scoreHome = raw.home_score ?? raw.homeScore ?? raw.scores?.home ?? raw.score?.home ?? "—";
  const scoreAway = raw.away_score ?? raw.awayScore ?? raw.scores?.away ?? raw.score?.away ?? "—";
  const statusRaw = String(raw.status || raw.state || raw.match_status || "").toLowerCase();
  const status = /live|in.?play|playing|1h|2h|set/.test(statusRaw) ? "LIVE" : /finish|ended|complete|final/.test(statusRaw) ? "FINISHED" : "SCHEDULED";
  return { id:String(raw.id || raw.slug || `${sport}-${i}-${home}`), sport, league:raw.competition?.name || raw.league?.name || raw.league_name || raw.tournament || raw.competition || sport.toUpperCase(), home, away, homeScore:scoreHome, awayScore:scoreAway, status, minute:raw.minute || raw.time || raw.start_time || raw.date || "" };
}
function App() {
  const [language,setLanguage] = useState("Français");
  const [sport,setSport] = useState("all");
  const [tab,setTab] = useState("live");
  const [query,setQuery] = useState("");
  const [favorites,setFavorites] = useState(() => { try { return JSON.parse(localStorage.getItem("mz-favorites") || "[]"); } catch { return []; } });
  const [matches,setMatches] = useState(demoMatches);
  const [loading,setLoading] = useState(false);
  const [apiStatus,setApiStatus] = useState("demo");
  const [lastUpdated,setLastUpdated] = useState(null);
  const t = translations[language];
  const rtl = language === "العربية";

  async function loadMatches() {
    setLoading(true);
    try {
      const sports = sport === "all" ? ["football","tennis","basketball","cricket"] : [sport];
      const responses = await Promise.all(sports.map(async s => {
        const res = await fetch(`${API}?sport=${encodeURIComponent(s)}`);
        if (!res.ok) throw new Error("API unavailable");
        const data = await res.json();
        const list = Array.isArray(data.matches) ? data.matches : Array.isArray(data.data) ? data.data : Array.isArray(data.results) ? data.results : [];
        return list.map((m,i) => normalise(m,s,i)).filter(Boolean);
      }));
      const result = responses.flat();
      if (result.length) { setMatches(result); setApiStatus("live"); }
      else { setMatches(demoMatches); setApiStatus("demo"); }
      setLastUpdated(new Date());
    } catch {
      setMatches(demoMatches);
      setApiStatus("demo");
      setLastUpdated(new Date());
    } finally { setLoading(false); }
  }
  useEffect(() => { loadMatches(); }, [sport]);
  useEffect(() => { localStorage.setItem("mz-favorites", JSON.stringify(favorites)); }, [favorites]);
  useEffect(() => { const timer = setInterval(loadMatches, 60000); return () => clearInterval(timer); }, [sport]);

  const shown = useMemo(() => matches.filter(m => {
    const sportOk = sport === "all" || m.sport === sport;
    const searchOk = `${m.home} ${m.away} ${m.league}`.toLowerCase().includes(query.toLowerCase());
    const tabOk = tab === "favorites" ? favorites.includes(m.id) : tab === "live" ? m.status === "LIVE" || m.status === "SCHEDULED" : true;
    return sportOk && searchOk && tabOk;
  }), [matches,sport,query,tab,favorites]);
  function toggleFavorite(id) { setFavorites(old => old.includes(id) ? old.filter(x => x !== id) : [...old,id]); }
  const sports = [{id:"all",label:t.all,icon:Globe2},{id:"football",label:t.football,icon:Activity},{id:"tennis",label:t.tennis,icon:Trophy}];
  return <div className={rtl ? "app rtl" : "app"} dir={rtl ? "rtl" : "ltr"}>
    <header className="topbar">
      <a className="brand" href="#"><span className="brand-mark"><Flame size={24}/></span><span>SUPER<span className="brand-accent">SCORE</span><small>THE GAME NEVER STOPS</small></span></a>
      <div className="header-actions">
        <div className="lang-select"><Languages size={16}/><select value={language} onChange={e=>setLanguage(e.target.value)} aria-label="Language"><option>Français</option><option>العربية</option><option>English</option></select><ChevronDown size={14}/></div>
        <button className="icon-button mobile-menu" aria-label="Menu"><Menu size={20}/></button>
      </div>
    </header>
    <main className="layout">
      <aside className="sidebar">
        <div className="side-heading">MENU</div>
        <button className={`side-link ${tab==="live"?"active":""}`} onClick={()=>setTab("live")}><Activity size={18}/>{t.live}<span className="live-dot"/></button>
        <button className={`side-link ${tab==="favorites"?"active":""}`} onClick={()=>setTab("favorites")}><Star size={18}/>{t.favorites}<span className="count">{favorites.length}</span></button>
        <button className={`side-link ${tab==="standings"?"active":""}`} onClick={()=>setTab("standings")}><Trophy size={18}/>{t.standings}</button>
        <div className="side-heading sports-heading">SPORTS</div>
        {sports.map(s => <button key={s.id} className={`side-link ${sport===s.id?"selected":""}`} onClick={()=>setSport(s.id)}><s.icon size={18}/>{s.label}</button>)}
        <div className="sidebar-note"><CircleHelp size={17}/><p>Scores are supplied by a third-party data provider. Coverage and update frequency may vary.</p></div>
      </aside>
      <section className="content">
        <div className="hero">
          <div><div className="eyebrow"><span className="live-dot"/> SPORTS • LIVE • RESULTS</div><h1>FEEL THE <span>GAME.</span><br/>OWN THE MOMENT.</h1><p>Live scores. Big moments. Pure adrenaline.</p></div>
          <div className="hero-ball">SS<span>✦</span></div>
          <div className="hero-glow"/>
        </div>
        <div className="content-heading"><div><h2>{tab==="favorites"?t.favorites:tab==="standings"?t.standings:t.live}</h2><p>{lastUpdated ? `Mis à jour ${lastUpdated.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}` : t.loading}</p></div><button className="refresh-button" onClick={loadMatches} disabled={loading}><Activity size={16} className={loading?"spin":""}/>{t.refresh}</button></div>
        <div className="toolbar">
          <div className="sport-tabs">{sports.map(s=><button key={s.id} onClick={()=>setSport(s.id)} className={sport===s.id?"chosen":""}>{s.label}</button>)}</div>
          <label className="search-box"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={t.search}/>{query && <button onClick={()=>setQuery("")} aria-label="Clear search"><X size={15}/></button>}</label>
          <button className="download-button" onClick={() => { const rows = [["Sport","League","Home","Home score","Away","Away score","Status","Time"], ...shown.map(m=>[m.sport,m.league,m.home,m.homeScore,m.away,m.awayScore,m.status,m.minute || ""])]; const csv = rows.map(row=>row.map(v=>`"${String(v ?? "").replaceAll("\"","\"\"")}"`).join(",")).join("\r\n"); const blob = new Blob(["\ufeff"+csv], {type:"text/csv;charset=utf-8;"}); const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href=url; a.download=`superscore-matches-${new Date().toISOString().slice(0,10)}.csv`; a.click(); URL.revokeObjectURL(url); }}><Download size={16}/> Download matches</button>
        </div>
        {apiStatus==="demo" && <div className="notice"><span className="notice-dot"/> {t.demo}: displayed scores are illustrative and are NOT live results. Configure the API to load real data.</div>}
        {tab==="standings" ? <div className="empty-panel"><Trophy size={30}/><h3>{t.standings}</h3><p>La version initiale affiche les matchs. Les classements officiels seront disponibles quand un endpoint compatible sera configuré.</p></div> :
          <div className="match-list">
            <div className="list-head"><span>{t.allMatches.toUpperCase()}</span><span>{shown.length} MATCHES</span></div>
            {shown.map(m=><article className="match-row" key={m.id}>
              <div className="match-meta"><span className="league-dot"/><span>{m.league}</span><span className="sport-label">{m.sport}</span></div>
              <div className="match-main">
                <div className="teams"><div className="team"><span className="team-crest">{m.home.slice(0,1).toUpperCase()}</span><span>{m.home}</span></div><div className="team"><span className="team-crest away">{m.away.slice(0,1).toUpperCase()}</span><span>{m.away}</span></div></div>
                <div className="scores"><span className={m.status==="LIVE"?"score-live":""}>{m.homeScore}</span><span className={m.status==="LIVE"?"score-live":""}>{m.awayScore}</span></div>
                <div className="match-state">{m.status==="LIVE"?<><span className="live-dot"/><b>{m.minute || t.live}</b></>:m.status==="FINISHED"?<span className="finished">{t.finished}</span>:<><Clock3 size={14}/><span>{m.minute || t.upcoming}</span></>}</div>
                <button className={`favorite-button ${favorites.includes(m.id)?"favorited":""}`} onClick={()=>toggleFavorite(m.id)} aria-label="Toggle favorite"><Star size={18} fill={favorites.includes(m.id)?"currentColor":"none"}/></button>
              </div>
            </article>)}
            {shown.length===0 && <div className="empty-panel"><Search size={28}/><h3>{t.noMatches}</h3><p>{tab==="favorites"?t.emptyFav:"Essayez une autre recherche."}</p></div>}
          </div>}
        <div className="data-footer"><span>{t.powered}</span><a href="https://sportscore.com/" target="_blank" rel="noreferrer">Powered by SportScore ↗</a></div>
        <footer>© {new Date().getFullYear()} SUPERSCORE · Built for the love of the game.</footer>
      </section>
    </main>
  </div>;
}
createRoot(document.getElementById("root")).render(<App/>);