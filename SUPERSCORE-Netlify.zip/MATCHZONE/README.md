# SUPERSCORE — Netlify Starter

A bold, animated sports-score dashboard built with React + Vite and deployable to Netlify.

## What is included
- SUPERSCORE branding with animated neon-red/blue dark UI and responsive layouts.
- French, Arabic (RTL), and English language selection.
- Football and tennis filters, search, favorites saved in this browser, refresh button, and periodic refresh.
- Download currently displayed matches as a CSV file (opens in Excel / Google Sheets).
- Netlify Function proxy for the SportScore public matches endpoint.
- Demo-mode notice so example scores are not mistaken for real live results.
- Reduced-motion accessibility support.

## Important about live data
This project uses the SportScore matches endpoint through a Netlify Function. Live coverage and API response formats can vary. If the provider is unavailable, the page deliberately falls back to clearly labelled illustrative demo scores. Do not present those demo scores as real results. Check the provider's current terms, attribution rules, endpoint availability and coverage before publishing: https://sportscore.com/developers/

Standings and detailed match statistics are not yet connected to verified endpoints. The download feature exports the matches currently shown on screen, including demo rows if the app is in demo mode.

## Run locally
Node.js 20+ recommended.

```bash
npm install
npm run dev
```

To test the Netlify Function locally, install Netlify CLI and run `netlify dev`.

## Deploy to Netlify
1. Upload this folder to a GitHub repository.
2. In Netlify, choose **Add new site → Import an existing project** and connect the repository.
3. Build command: `npm run build`
4. Publish directory: `dist`
5. Deploy. `netlify.toml` includes these defaults.

No provider API key is currently configured in this starter. If you change providers, keep secret API keys in Netlify environment variables and call the provider through a server-side function, not browser code.
