// Netlify serverless proxy for SportScore. The provider API key is not needed
// for the documented public attribution tier. See README for licensing caveats.
const allowedSports = new Set(["football", "tennis", "basketball", "cricket"]);
export default async (request) => {
  const url = new URL(request.url);
  const sport = (url.searchParams.get("sport") || "football").toLowerCase();
  if (!allowedSports.has(sport)) {
    return new Response(JSON.stringify({ error: "Unsupported sport" }), {
      status: 400, headers: { "content-type": "application/json", "cache-control": "no-store" }
    });
  }
  try {
    const upstream = await fetch(`https://sportscore.com/api/widget/matches/?sport=${encodeURIComponent(sport)}&limit=50`, {
      headers: { "accept": "application/json" }
    });
    const body = await upstream.text();
    return new Response(body, {
      status: upstream.status,
      headers: {
        "content-type": upstream.headers.get("content-type") || "application/json",
        "cache-control": "public, max-age=30, s-maxage=60",
        "access-control-allow-origin": "*"
      }
    });
  } catch {
    return new Response(JSON.stringify({ error: "Sports data provider unavailable", matches: [] }), {
      status: 502, headers: { "content-type": "application/json", "cache-control": "no-store" }
    });
  }
};